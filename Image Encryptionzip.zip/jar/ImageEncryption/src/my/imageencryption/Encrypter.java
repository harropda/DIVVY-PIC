/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.imageencryption;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author David Harrop 03298051 & Krzysztof Pawlik 16138147
 * Encryption: hash the password and re-write the input file, including the hashed 
 * password in the bytes, effectively encrypting it.
 * Decryption: hash the password and compare it to the hashed password retrieved 
 * from the file to be decrypted.  If they match, then re-write the encrypted 
 * file without the hashed password bytes, effectively decrypting it
 */
public class Encrypter {
    private File outputfile;
    public Throwable t = new Throwable("Invalid password");
    
    boolean compareHashes(File file, String keyHash) throws FileNotFoundException, IOException {        
        StringBuffer keyHashFromFile;
        //reading key hash from file
        try (BufferedInputStream fileReader = new BufferedInputStream(new FileInputStream(file.getAbsolutePath()))) {
            //reading key hash from file
            keyHashFromFile = new StringBuffer(128);
            for(int i=0; i<128; i++) {
                keyHashFromFile.append((char)fileReader.read());
            }   //verifying both hashes
            System.out.println("keyHashFromFile.to string()= "+keyHashFromFile);
            System.out.println("keyHash= "+keyHash);
        }
        return keyHashFromFile.toString().equals(keyHash);
    }
    
    private byte[] getHashB(String key) throws NoSuchAlgorithmException{
        byte[] keyHash;
        final MessageDigest md = MessageDigest.getInstance("SHA-512");
        keyHash = md.digest(key.getBytes());
        StringBuilder sb = new StringBuilder();
        for(int i=0; i< keyHash.length ;i++) {
            sb.append(Integer.toString((keyHash[i] & 0xff) + 0x100, 16).substring(1));
        }
        String hashOfPassword = sb.toString();
        System.out.println("hashOfPassword length= "+hashOfPassword.length());
        System.out.println("hashOfPassword = " +hashOfPassword);
        return hashOfPassword.getBytes();                
    }
    
    private String getHashS(String key) throws NoSuchAlgorithmException {
        byte[] keyHash;
        final MessageDigest md = MessageDigest.getInstance("SHA-512");
        keyHash = md.digest(key.getBytes());
        StringBuilder sb = new StringBuilder();
        for(int i=0; i< keyHash.length ;i++) {
             sb.append(Integer.toString((keyHash[i] & 0xff) + 0x100, 16).substring(1));
        }
        String hashOfPassword = sb.toString();
        System.out.println("hashOfPassword length= "+hashOfPassword.length());
        System.out.println("hashOfPassword = " +hashOfPassword);
        return hashOfPassword;
    }
    
    public void encrypt(File file, String password){
        byte[] keyHash;
        if(!file.isDirectory()) {
            try {
                keyHash=getHashB(password);
                
                outputfile=new File(file.getAbsolutePath().concat(".crypt"));
                if(outputfile.exists()) {
                    outputfile.delete();
                    outputfile=new File(file.getAbsolutePath().concat(".crypt"));
                }
                                
                FileOutputStream fileWriter;
                try (BufferedInputStream fileReader = new BufferedInputStream(new FileInputStream(file.getAbsolutePath()))) {
                    fileWriter = new FileOutputStream (outputfile, true);
                    //writing key hash to file
                    fileWriter.write(keyHash, 0, 128);
                    //encrypting content & writing
                    byte[] buffer = new byte[262144];
                    int bufferSize=buffer.length;
                    int pwSize=password.length();
                    while(fileReader.available()>0) {
                        int bytesCopied=fileReader.read(buffer);
                        for(int i=0,keyCounter=0; i<bufferSize; i++, keyCounter%=pwSize ) {
                            buffer[i]+=password.toCharArray()[keyCounter];
                        }
                        fileWriter.write(buffer, 0, bytesCopied);
                    }
                }
                file.delete();
                fileWriter.close();                
            } 
            catch (NoSuchAlgorithmException e){
                ExceptionUI exUI = new ExceptionUI("NoSuchAlgorithmException!", "Fatal Error 01", e);
                exUI.setVisible(true);
                Logger.getLogger(Encrypter.class.getName()).log(Level.SEVERE, null, e);
            }
            catch (SecurityException e){
                ExceptionUI exUI = new ExceptionUI("Error!", file+": action not permitted", e);
                exUI.setVisible(true);
                Logger.getLogger(Encrypter.class.getName()).log(Level.SEVERE, null, e);
            }
            catch (FileNotFoundException e){
                ExceptionUI exUI = new ExceptionUI("Error!", file+": not found!", e);
                exUI.setVisible(true);
                Logger.getLogger(Encrypter.class.getName()).log(Level.SEVERE, null, e);
            }
            catch (IOException e){
                ExceptionUI exUI = new ExceptionUI("Error!", file+" can not be read or written!", e);
                exUI.setVisible(true);
                Logger.getLogger(Encrypter.class.getName()).log(Level.SEVERE, null, e);
            }
            catch (Exception e){
                 ExceptionUI exUI = new ExceptionUI("Unexpected System Error!", "Fatal Error 02", e);
                exUI.setVisible(true);
                 Logger.getLogger(Encrypter.class.getName()).log(Level.SEVERE, null, e);
            }            
        }
    }
    
    public void decrypt(File file, String password) {
        String keyHash;
        if(!file.isDirectory()) {
            try {
                keyHash=getHashS(password);    
                if( compareHashes(file, keyHash)) {
                    outputfile=new File(file.getAbsolutePath().substring(0, file.getAbsolutePath().length()-6));
                
                    FileOutputStream fileWriter;
                    try (BufferedInputStream fileReader = new BufferedInputStream(new FileInputStream(file.getAbsolutePath()))) {
                        fileWriter = new FileOutputStream (outputfile);
                        //decrypting content & writing
                        byte[] buffer = new byte[262144];
                        int bufferSize=buffer.length;
                        int keySize=password.length();
                        for(int i=0; i<128; i++) {
                            if(fileReader.available()>0) {
                                fileReader.read();
                            }
                        } while(fileReader.available()>0) {
                            int bytesCopied=fileReader.read(buffer);
                            for(int i=0,keyCounter=0; i<bufferSize; i++, keyCounter%=keySize ) {
                                buffer[i]-=password.toCharArray()[keyCounter];
                            }                            
                            fileWriter.write(buffer, 0, bytesCopied);
                        }
                    }
                    fileWriter.close();
                } else if(!compareHashes(file, keyHash)) {                    
                    new ExceptionUI("Error!", "Invalid password", t).setVisible(true);
                }                
            }
            catch (NoSuchAlgorithmException e) {
                new ExceptionUI("NoSuchAlgorithmException!", "Fatal Error 01", e).setVisible(true);
                Logger.getLogger(Encrypter.class.getName()).log(Level.SEVERE, null, e);
            }
            catch (SecurityException e) {
                new ExceptionUI("Error!", file+": action not permitted", e).setVisible(true);
            }
            catch (FileNotFoundException e) {
                new ExceptionUI("Error!", file+": not found!", e).setVisible(true);
            }
            catch (IOException e) {
                new ExceptionUI("Error!", file+" can not be read or written!", e).setVisible(true);
            }            
            catch (Exception e) {
                 new ExceptionUI("Unexpected System Error!", "Fatal Error 02", e).setVisible(true);
            }            
        }
    }
}
