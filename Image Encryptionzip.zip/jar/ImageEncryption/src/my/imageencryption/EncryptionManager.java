/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.imageencryption;

import javax.swing.SwingWorker;
import java.io.File;

/**
 * @author David Harrop 03298051 & Krzysztof Pawlik 16138147
 * Determine the action to be performed, then cycle through each of the files
 * in our array, performing the desired action.
 */
public class EncryptionManager extends SwingWorker <Boolean,Boolean> {
    File[] fileList;
    String password;
    String action;
    Encrypter encrypter;
    
    public EncryptionManager(File[] fileList, String password, String action) {
        this.fileList = fileList;
        this.password = password;
        this.action = action;
        encrypter = new Encrypter();         
    }
    
    @Override
    protected Boolean doInBackground() {
        try {
            docrypt(fileList); 
        }
        // if the docrypt method throws any exception, return a general error
        catch (Exception e) {
            ExceptionUI exUI = new ExceptionUI("Unexpected System Error!", "Fatal Error 03", e);
            exUI.setVisible(true);     
        }
        finally {
            return true;
        }
    }

    private void docrypt(File[] fileList) throws Exception {
        for(File file:this.fileList){
            // No point trying to encrypt a folder or a non-existent file
            if(!file.isDirectory() && file.exists()) {    
                if ("encrypt".equals(this.action)) {
                    encrypter.encrypt(file, this.password);
                } else {
                    encrypter.decrypt(file, this.password);
                }                
            } else {
            } 
        }         
    }
}
